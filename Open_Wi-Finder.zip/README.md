# Open Wi-Finder

<h2>Work-in-Progress submission for ESRI App Challenge 2015</h2>
<p>ESRI ArcGIS Javascript API</p>
<p>CodyHouse Full-Screen Pop-Out Navigation</p>
<p>Firebase Backend</p>


